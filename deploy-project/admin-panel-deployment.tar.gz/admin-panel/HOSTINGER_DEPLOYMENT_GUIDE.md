# Hostinger Deployment Guide - Admin Panel

This guide explains how to deploy the Admin Panel to Hostinger VPS.

## Prerequisites

1. A Hostinger VPS with Node.js 18+ installed
2. SSH access to your VPS
3. A domain or subdomain pointed to your VPS IP

---

## Files to Upload

Upload the entire `deploy-project/admin-panel` folder to your VPS. The folder should contain:

```
admin-panel/
├── .next/
│   └── static/          # Static assets
├── admin-panel/         # The Next.js standalone server
│   └── server.js        # Main entry point
├── node_modules/        # Required dependencies
├── public/              # Public assets
└── .env.production      # Environment variables (already included)
```

---

## Step 1: Upload to VPS

Use SFTP (FileZilla) or SCP to upload:

```bash
# Using SCP (from your local machine)
scp -r deploy-project/admin-panel/* user@your-vps-ip:/var/www/admin-panel/
```

Or use **FileZilla**:
1. Connect to your VPS using SFTP
2. Navigate to `/var/www/admin-panel/` (create if doesn't exist)
3. Upload all contents of `deploy-project/admin-panel/`

---

## Step 2: SSH into VPS and Setup

```bash
# Connect to your VPS
ssh user@your-vps-ip

# Navigate to the project folder
cd /var/www/admin-panel

# Make server.js executable (if needed)
chmod +x admin-panel/server.js
```

---

## Step 3: Install PM2 (Process Manager)

PM2 keeps your app running and restarts it if it crashes:

```bash
# Install PM2 globally
npm install -g pm2

# Start the Next.js server
cd /var/www/admin-panel
PORT=3000 pm2 start admin-panel/server.js --name "admin-panel"

# Save PM2 process list (so it restarts on reboot)
pm2 save

# Enable PM2 to start on boot
pm2 startup
```

---

## Step 4: Configure Nginx (Reverse Proxy)

Create an Nginx config for your domain:

```bash
sudo nano /etc/nginx/sites-available/admin-panel
```

Paste this configuration (replace `admin.yourdomain.com` with your actual domain):

```nginx
server {
    listen 80;
    server_name admin.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site and reload Nginx:

```bash
sudo ln -s /etc/nginx/sites-available/admin-panel /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## Step 5: Setup SSL (HTTPS)

Use Certbot for free SSL:

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d admin.yourdomain.com
```

Follow the prompts to enable HTTPS.

---

## Useful PM2 Commands

```bash
# View logs
pm2 logs admin-panel

# Restart app
pm2 restart admin-panel

# Stop app
pm2 stop admin-panel

# View status
pm2 status
```

---

## Troubleshooting

### App not starting?
- Check logs: `pm2 logs admin-panel`
- Verify `.env.production` exists with correct values
- Make sure port 3000 is not in use

### 502 Bad Gateway?
- Check if the app is running: `pm2 status`
- Verify Nginx config: `sudo nginx -t`

### Firebase errors?
- Verify all `NEXT_PUBLIC_FIREBASE_*` variables are set correctly in `.env.production`
