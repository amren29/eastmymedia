module.exports=[96530,(e,o,d)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_api_users_%5Bid%5D_route_actions_43a754fe.js.map