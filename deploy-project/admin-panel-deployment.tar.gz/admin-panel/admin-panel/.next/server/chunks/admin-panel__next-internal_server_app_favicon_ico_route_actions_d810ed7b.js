module.exports=[15296,(e,o,d)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_favicon_ico_route_actions_d810ed7b.js.map