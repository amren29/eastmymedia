module.exports=[42596,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_users_page_actions_a3be0b26.js.map