module.exports=[4656,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_pending-approval_page_actions_b998b491.js.map