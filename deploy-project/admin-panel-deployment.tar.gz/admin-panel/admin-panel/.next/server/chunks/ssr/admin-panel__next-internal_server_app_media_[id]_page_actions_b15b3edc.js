module.exports=[59280,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_media_%5Bid%5D_page_actions_b15b3edc.js.map