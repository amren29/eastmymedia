module.exports=[19742,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_media_new_page_actions_c813031c.js.map