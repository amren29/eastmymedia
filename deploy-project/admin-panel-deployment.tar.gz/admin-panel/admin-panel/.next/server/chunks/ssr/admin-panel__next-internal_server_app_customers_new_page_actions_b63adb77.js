module.exports=[58881,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_customers_new_page_actions_b63adb77.js.map