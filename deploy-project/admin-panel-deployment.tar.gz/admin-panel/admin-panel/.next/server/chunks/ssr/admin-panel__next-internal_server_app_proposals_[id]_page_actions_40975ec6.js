module.exports=[31999,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_proposals_%5Bid%5D_page_actions_40975ec6.js.map