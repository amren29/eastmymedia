module.exports=[93350,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_proposals_page_actions_f5afb1c5.js.map