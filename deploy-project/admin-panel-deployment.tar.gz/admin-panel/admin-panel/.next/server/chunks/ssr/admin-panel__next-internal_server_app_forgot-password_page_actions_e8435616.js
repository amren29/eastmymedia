module.exports=[27399,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_forgot-password_page_actions_e8435616.js.map