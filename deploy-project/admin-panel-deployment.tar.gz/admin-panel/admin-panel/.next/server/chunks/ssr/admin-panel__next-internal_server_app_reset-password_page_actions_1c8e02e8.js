module.exports=[32470,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_reset-password_page_actions_1c8e02e8.js.map