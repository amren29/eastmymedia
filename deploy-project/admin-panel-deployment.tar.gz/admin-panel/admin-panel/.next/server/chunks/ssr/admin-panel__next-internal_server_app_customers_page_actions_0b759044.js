module.exports=[69771,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_customers_page_actions_0b759044.js.map