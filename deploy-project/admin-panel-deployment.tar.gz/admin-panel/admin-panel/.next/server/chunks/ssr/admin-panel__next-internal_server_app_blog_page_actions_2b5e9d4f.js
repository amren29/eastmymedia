module.exports=[74786,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_blog_page_actions_2b5e9d4f.js.map