module.exports=[60687,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_setup_page_actions_0b53bd7d.js.map