module.exports=[36613,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_proposals_new_page_actions_c123c16c.js.map