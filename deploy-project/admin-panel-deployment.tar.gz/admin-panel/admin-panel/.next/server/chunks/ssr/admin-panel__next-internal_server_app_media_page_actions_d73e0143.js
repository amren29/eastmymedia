module.exports=[90281,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_media_page_actions_d73e0143.js.map