module.exports=[50826,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_blog_%5Bid%5D_page_actions_e267365b.js.map