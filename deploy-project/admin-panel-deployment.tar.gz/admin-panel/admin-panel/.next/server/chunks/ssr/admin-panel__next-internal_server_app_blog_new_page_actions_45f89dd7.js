module.exports=[95690,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_blog_new_page_actions_45f89dd7.js.map