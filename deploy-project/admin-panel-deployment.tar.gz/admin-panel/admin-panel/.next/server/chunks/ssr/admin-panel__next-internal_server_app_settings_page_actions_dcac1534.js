module.exports=[42360,(a,b,c)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_settings_page_actions_dcac1534.js.map