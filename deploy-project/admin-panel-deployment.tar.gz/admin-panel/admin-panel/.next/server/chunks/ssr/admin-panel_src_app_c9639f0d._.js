module.exports=[5214,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},86364,a=>{"use strict";let b={src:a.i(5214).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=admin-panel_src_app_c9639f0d._.js.map