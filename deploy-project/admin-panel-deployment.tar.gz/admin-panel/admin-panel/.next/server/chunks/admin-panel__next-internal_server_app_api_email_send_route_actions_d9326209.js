module.exports=[96629,(e,o,d)=>{}];

//# sourceMappingURL=admin-panel__next-internal_server_app_api_email_send_route_actions_d9326209.js.map