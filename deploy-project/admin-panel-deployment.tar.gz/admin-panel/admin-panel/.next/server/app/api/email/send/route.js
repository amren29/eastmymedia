var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/email/send/route.js")
R.c("server/chunks/[root-of-the-server]__46ddaec7._.js")
R.c("server/chunks/[root-of-the-server]__055b6193._.js")
R.c("server/chunks/[root-of-the-server]__fbf2e75b._.js")
R.c("server/chunks/admin-panel__next-internal_server_app_api_email_send_route_actions_d9326209.js")
R.m(23623)
module.exports=R.m(23623).exports
