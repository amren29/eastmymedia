var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__5dce6c79._.js")
R.c("server/chunks/[root-of-the-server]__055b6193._.js")
R.c("server/chunks/admin-panel__next-internal_server_app_api_users_[id]_route_actions_43a754fe.js")
R.m(93191)
module.exports=R.m(93191).exports
