var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__b89b5a39._.js")
R.c("server/chunks/[root-of-the-server]__055b6193._.js")
R.c("server/chunks/a8b33_next_dist_esm_build_templates_app-route_ec498bfe.js")
R.c("server/chunks/admin-panel__next-internal_server_app_favicon_ico_route_actions_d810ed7b.js")
R.m(26394)
module.exports=R.m(26394).exports
