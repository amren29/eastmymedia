1:"$Sreact.fragment"
2:I[2633,["/_next/static/chunks/9ab49c1324f61137.js","/_next/static/chunks/e09d3d836a18a9ab.js"],"ViewportBoundary"]
4:I[2633,["/_next/static/chunks/9ab49c1324f61137.js","/_next/static/chunks/e09d3d836a18a9ab.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
7:I[38489,["/_next/static/chunks/9ab49c1324f61137.js","/_next/static/chunks/e09d3d836a18a9ab.js"],"IconMark"]
0:{"buildId":"GeGgV_XVonc4d5A90V1TE","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L7","1",{}]]
