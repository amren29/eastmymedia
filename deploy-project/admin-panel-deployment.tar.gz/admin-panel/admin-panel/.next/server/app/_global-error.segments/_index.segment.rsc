1:"$Sreact.fragment"
2:I[95955,["/_next/static/chunks/9ab49c1324f61137.js","/_next/static/chunks/e09d3d836a18a9ab.js"],"default"]
3:I[82819,["/_next/static/chunks/9ab49c1324f61137.js","/_next/static/chunks/e09d3d836a18a9ab.js"],"default"]
0:{"buildId":"GeGgV_XVonc4d5A90V1TE","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
