globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/38edaa8084252260.js",
    "static/chunks/9959aeda5dfaa630.js",
    "static/chunks/1157ea99c9b8b707.js",
    "static/chunks/d3ae4ecb55067b49.js",
    "static/chunks/5f4e9ddbbc8c57d6.js",
    "static/chunks/turbopack-87a48653841817db.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];